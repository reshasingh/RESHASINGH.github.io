# Resha Singh — Portfolio

This is the first portfolio draft based on the 10 resume variants supplied.

## Positioning
Strategy + AI Transformation + Revenue + Operations.

## Before publishing
Replace the three profile placeholders in `index.html`:
- LinkedIn
- GitHub
- X / Twitter

Also replace the Hermes GitHub project placeholder with the exact repository URL.

## Suggested next iteration
1. Add a dedicated case-study page for Hermes.
2. Add 3–5 detailed case studies (Hermes, ART Automation, GHL, AI Chatbot, Revenue/Retention).
3. Add a downloadable master resume.
4. Add a simple contact form or email CTA.
5. Publish through GitHub Pages.
